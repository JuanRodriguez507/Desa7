      </div>
    </main>

    <footer>
      <p>&copy; MotoSport | <?= date('Y'); ?></p>
    </footer>
  </div>
</body>

</html>