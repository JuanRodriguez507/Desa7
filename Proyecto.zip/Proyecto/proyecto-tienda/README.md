# Proyecto de Tienda
Proyecto de tienda realizado con PHP con el paradigma POO y MVC. Este pequeño proyecto se realizo para poner en practica los conocimientos adquiridos. 

El sitio permite realizar registro y login de usuarios y una vez registrado hacer "compras" de los productos disponibles. También, permite hacer mantenimiento de las categorias de compras, los productos y del carrito de compra. 

## Caracteristicas
- Registro de usuarios
- Login de usuarios
- Categorias de tienda
- Productos de tienda
- Mostrar productos
- Carrito de compra
- Pedidos de la tienda
