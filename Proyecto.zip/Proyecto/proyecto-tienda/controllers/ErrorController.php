<?php
  class ErrorController
  {
    public function index()
    {
      echo '<h1>Página no encontrada</h1>';
    }
  }
?>

