<?php
  define('URL_BASE', 'http://localhost/desa7/Proyecto/proyecto-tienda/');
  define('CONTROLLER_DEFAULT', 'ProductoController');
  define('ACCION_DEFAULT', 'index'); 
?>